#!/usr/bin/Rscript
options(scipen=999, expressions=10000)
source("lib/info_theory.R", chdir=TRUE)
source("lib/clean_transform.R", chdir=TRUE)
source("lib/cluster_columns.R", chdir=TRUE)
source("lib/map.R")

#########
# ATLAS #
#########
#------------------- #
# CREATES THE LAYERS #
#------------------- #
partition_column <- function(column, init_k){
    clean_column <- na.omit(column)
    NAs <- attr(clean_column,"na.action")

    analysis <- kmeans(clean_column, min(init_k, length(unique(column))), nstart=3)

    if (is.null(NAs)) return(analysis)
    
    f_model       <- rep(NA, length(column))
    f_model[-NAs] <- analysis$cluster
    
    return(list(cluster = f_model,
                centers = analysis$center))
}

create_layers <- function(data, init_k){
    scaled <- scale(as.matrix(data))
    
    analysis <- apply(scaled, 2, partition_column, init_k)
    names(analysis) <- names(data)
    
    layers   <- as.data.frame(lapply(analysis, function(a) a$cluster))
    names(layers) <- names(data)
    
    drillup <- lapply(analysis, function(a) kmeans(a$centers, 2, nstart=5)$cluster)
    names(drillup) <- names(data)
    
    list(layers=layers, drillup=drillup)
}
#-------------------------- #
# CLUSTERING OF THE 1D MAPS #
#-------------------------- #
cluster_layers <- function(layers, print_results=FALSE) {
    # Trivial case
    if (ncol(layers) < 2) return(list(
        clusters=list(c(names(layers)[[1]])),
        dist_matrix=matrix(NA, nrow=1, ncol=1)
    ))

    # Calculates the distance pairs
    dist_matrix <- variation_information_m(layers)
    # Performs the clustering
    dist_object <- as.dist(dist_matrix)
    dendrogram <- hclust(dist_object, "complete")

    # Cuts
    splits <- cutreeDynamic(dendrogram, minClusterSize=2, method="tree", 
                            deepSplit = FALSE)

    outliers <- (splits == 0)
    if (any(outliers))
        splits[outliers] <- seq(max(splits) +1, length = sum(outliers))
    clusters <- lapply(unique(splits), function(s) names(layers)[splits == s])

    # Returns
    list(clusters    = clusters,
         dist_matrix = dist_matrix)
}

#-----------------#
# Ordering layers #
#-----------------#
order_layers <- function(col_indices, data){
    if (length(col_indices) < 2) return(col_indices)
    entropy <- sapply(data[,col_indices], function(l) entropy(l))
    col_indices[order(entropy)]
}

order_layer_clusters <- function(layer_clusters, data){
    lapply(layer_clusters, order_layers, data)
}
#-------------#
# MAP MERGING #
#------------ #
### Merging util ###
merge_maps <- function(layers) {
    do.call(paste, c(layers, sep=""))
}

merge_all_layers <- function(layers, layer_clusters, drillups, nlayers=3){
    # Simplifies
    layers_drilled <- lapply(names(layers), function(colname){
        clusters <- layers[[colname]]
        drillups[[colname]][clusters]
    })
    names(layers_drilled) <- names(layers)
    
    # Merges
    out <- lapply(layer_clusters, function(col_indices, layers){
            if (length(col_indices) > nlayers) col_indices <- col_indices[1:nlayers]
            merge_maps(layers[col_indices])
    }, layers_drilled)

    out
}

# ------------- #
# MAIN FUNCTION #
# ------------- #
atlas <- function(data_file, nlayers=3, init_k = 8, print_results=FALSE){
    cat(" Crunching data set with", ncol(data_file),
         "columns and", nrow(data_file), "rows\n")

    TIME           <<- proc.time()["elapsed"]
    layer_analysis <- create_layers(data_file, init_k)
    layers         <- layer_analysis$layers
    drillups       <- layer_analysis$drillup
    cat("TIMING: layers", proc.time()["elapsed"] - TIME, "\n") ;  TIME <<- proc.time()["elapsed"]

    layer_analysis <- cluster_layers(layers, print_results)
    cat("TIMING: vertical", proc.time()["elapsed"] - TIME, "\n") ;  TIME <<- proc.time()["elapsed"]

    clusters <- layer_analysis$clusters
    maps <- merge_all_layers(layers, clusters, drillups, nlayers)
    cat("TIMING: clusters", proc.time()["elapsed"] - TIME, "\n") ;  TIME <<- proc.time()["elapsed"]

    # Packages
    not_NAs <- !is.na(maps)
    map_set <- lapply(1:length(not_NAs),
        function(i, clusters, maps){
            list(layers=clusters[[i]], map=maps[[i]])
        }, clusters[not_NAs], maps[not_NAs])

    cat(" ***** Done!\n")

    # Returns the stuff!
    map_set
}


############
# COMMANDS #
############
arguments   <- commandArgs(trailingOnly = TRUE)
data_file   <- arguments[1]
out         <- arguments[2]
n_clusters  <- as.numeric(arguments[3])
nlayers     <- as.integer(log2(n_clusters))

TIME <- proc.time()["elapsed"]

# Reads the data file
cat("Loading data\n")
data <- read.csv(data_file, header=FALSE, sep=";")
names(data) <- paste("col", 1:ncol(data), sep="")

# Removes useless columns
clean_names <- names(data)
for (col in names(data)){
    if (length(unique(data[[col]])) <= 2){
        data[[col]] <- NULL
    }
}
if (length(clean_names) > length(names(data)))
    warning("Dropped ", length(clean_names) - length(names(data)),
            "columns unsuitable for clustering", immediate. = TRUE)
    
# Clusters
map_out <- atlas(data, nlayers=nlayers)

# Writes output
cat("Output of DM clustering\n", file=out)
for (map in map_out){
    theme_bin <- rep(0, length(clean_names))
    theme_bin[which(clean_names %in% map$layers)] <- 1
    for (cluster in unique(map$map)){
        items <- which(map$map == cluster) - 1
        cat(theme_bin, 
            length(items),
            items,
            "\n",
            file=out, append=TRUE)
    }
}
