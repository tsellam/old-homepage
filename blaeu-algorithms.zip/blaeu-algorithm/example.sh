#!/bin/bash

./SimpleMap.R adult.csv simple_out 5
./MultiMap.R  adult.csv multi_out 5
./LightMap.R  adult.csv light_out 5
