#!/usr/bin/Rscript

options(scipen=999)
source("lib/info_theory.R", chdir=TRUE)
source("lib/clean_transform.R", chdir=TRUE)
source("lib/cluster_columns.R", chdir=TRUE)
source("lib/map.R")

arguments <- commandArgs(trailingOnly = TRUE)
in_file  	<- arguments[1]
out_file 	<- arguments[2]
K           <- as.integer(arguments[3])
sample_size <- as.integer(arguments[4])

# Reads data file
cat("Reading file\n")
full_data <- read.csv(in_file, header=FALSE, sep=";")

# Preprocesses
cat("Preprocessing\n")
clean_names <- names(full_data)
for (col in names(full_data)){
    column <- full_data[[col]]
    count_distinct <- length(unique(column))
    if (count_distinct < 2) full_data[[col]] <- NULL
    if (is.factor(column) && count_distinct > 15) full_data[[col]] <- NULL
}
if (length(clean_names) > length(names(data)))
    warning("Dropped ", length(clean_names) - length(names(full_data)),
            " columns unsuitable for clustering", immediate. = TRUE)
colnames(full_data) <- paste("map", 1:ncol(full_data), sep="")

# Samples
cat("Samples\n")
if (!is.na(sample_size)){
    sample_data <- full_data[sample(nrow(full_data), sample_size, replace=TRUE),]
    } else {
        sample_data <- full_data
}

# Gets column types
preprocessors <- infer_preprocessors(sample_data)

# Extracts themes
themes <- get_themes(sample_data, print_results=FALSE)

# Creates maps
cat("Creates maps from sample\n")
trees   <- create_maps(sample_data, themes, max_k=2*K, max_levels = as.integer(log2(K)),
                      preprocessors, print_results=FALSE)

# Applies to the rest of the data
cat("Applies to the larger dataset\n")
full_maps <- lapply(1:length(themes), function(i){
      theme <- themes[[i]]
      tree  <- trees[[i]]
	  predict(tree, full_data[theme], type="vector")
	})

cat("Writes file\n")
cat("Output of DM clustering\n", file=out_file)
for (i in 1:length(full_maps)){
  theme_bin <- rep(0, length(names(full_data)))
  theme_bin[which(names(full_data) %in% themes[[i]])] <- 1
  
  for (cluster in unique(full_maps[[i]])){
    items <- which(full_maps[[i]] == cluster) - 1
    cat(theme_bin, length(items), items, "\n", file=out_file, append=TRUE)
  }
}
