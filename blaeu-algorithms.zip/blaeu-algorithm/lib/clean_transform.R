#########
# Utils #
#########
catch_NAs <- function(column){
    column[column %in% c("n/a","","N/A","null", NaN, "", "?", "Null", "NULL", NULL)] <- NA
    column
}

###########################
# RULES FOR PREPROCESSING #
###########################
infer_preprocessors <- function(data){
    cat("Getting strategies for each column\n")
    processors <- lapply(data, function(column){

        if (class(column) %in% c("numeric", "integer")) {
            return("numeric")

        } else if(class(column) %in% c("factor", "character", "logical")){

            if (length(unique(column)) > min(length(column), 25)){
                return("categorica_hicard")

           } else {
                return("categorical_locard")
          }
        }
    })
    names(processors) <- colnames(data)

    cat("Done!\n")
    return(processors)
} 

exclude_hard_columns <- function(data, preprocessors){

    # Exludes columns with too many distinct values
    hard_columns <- which(preprocessors %in% "categorica_hicard")

    # Excludes columns with too little distinct values (=1...)
    ndistinct <- sapply(data, function(series){length(unique(series))})
    hard_columns <- c(hard_columns, which(ndistinct < 2))

    # Excludes colunms with too many NAs
    n_NAs <-  sapply(data, function(series){ sum(is.na(series)) })
    hard_columns <- c(hard_columns, which(n_NAs > 0.5 * nrow(data)))

    if (length(hard_columns) < 1) return(data)

    cat("Removing column(s):", paste0(names(data)[hard_columns]), "\n")
    data[,-hard_columns]
}
