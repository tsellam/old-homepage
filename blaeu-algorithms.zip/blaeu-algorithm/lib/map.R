library("cluster")
library("rpart")
#################
# Preprocessing #
#################
blaeu_preprocess <- function(data, preprocessors){
    cat("Introducing dummy variables\n")
    transformed <- list()

    # Preliminary checks
    if(is.null(data) || is.null(preprocessors))
        stop("Detected NULL values in input argument!")
    intersect <- intersect(names(data), names(preprocessors))
    if (length(intersect) < length(names(data)))
        stop("Missing preprocessor")
    if (nrow(data) < 2){
        warning("Cannot run preprocessing: too little rows")
        return(NULL)
    }

    # Actual preprocessing
    for (i in 1:ncol(data)){
        series <- data[[i]]
        type_series <- preprocessors[[names(data)[i]]]

        # Too little distinct values or too many missing values
        count_distinct <- length(unique(series))
        count_NAs      <- sum(is.na(series))
        if (count_distinct < 2 || count_NAs > 0.5 * nrow(data))
            next
      
        # Numeric type
        if (type_series == "numeric") {
            transformed[[length(transformed) + 1]]    <- as.numeric(scale(series))
            names(transformed)[[length(transformed)]] <- names(data)[i]

        # Categorical types
        } else if (type_series == "categorical_locard") {
            for (val in unique(series)){
                s <- rep(0, length(series))
                s[series == val] <- (0.5)^(1/2)
                s[is.na(series)] <- NA

                transformed[[length(transformed) + 1]] <- s
                new_colname <-  paste0(names(data)[i],val)
                names(transformed)[[length(transformed)]] <- new_colname 
            }

        # Others
        } else {
            stop(paste0("Unknown or unsupported type:", type_series))
        }
    }

    # Done!
    data.frame(transformed)
}

##############
# Clustering #
##############
blaeu_cluster <- function(data, K){
    # Preliminary checks
    if (!is.data.frame(data) || is.null(K))
        stop("Cannot run clustering: bad input")
    if (nrow(data) < 2){
        warning("Cannot run clustering: too little rows")
        return(NULL)
    }

    # Actual clustering
    cat(" * Clustering in progress...")
    TIME <-  proc.time()["elapsed"]
    clusters <- clara(data, min(K, nrow(data)-1), samples = 150, 
                      sampsize = min(nrow(data), 50),
                      stand = FALSE,  rngR = TRUE, pamLike = TRUE)
    cat("Done\n")

    return(clusters$clustering)
}

################
# Decison tree #
################
blaeu_tree <- function(data, labels, max_levels){
    # Preliminary checks
    if (!is.data.frame(data) || !is.numeric(labels) || is.null(max_levels))
        stop("Cannot build decision tree: bad input")
    if (nrow(data) < 2) {
        warning("Cannot run decision tree: too little rows")
        return(NULL)
    }

    # Actual decision tree creation
    tree <- rpart(labels ~ . , data=data, maxdepth=max_levels, method="class")
    print(tree)
    return(tree)

    #return(as.numeric(predict(tree, data, type = "vector")))
}

###############
# Wrapping up #
###############
create_maps <- function(data, themes, max_k=12, max_levels=3,
                        preprocessors, print_results=F){
    # Preliminary checks
    if (!is.data.frame(data) || !is.list(themes) || !is.list(preprocessors))
        error("Bad input data! One or more NULLs detected")
    if (length(themes) < 1 || ncol(data) < 1 || nrow(data) < 1){
        warning("Less than 1 theme, column or row to cluster")
        return(NULL)
    }

    # Preprocessing
    TIME <-  proc.time()["elapsed"]
    preprocessed_sets <- lapply(themes, function(theme) data[theme])

    # Clustering
    clusters_sets <- lapply(preprocessed_sets, blaeu_cluster, max_k)
    cat("TIMING: clustering:", proc.time()["elapsed"] - TIME, "\n") ;

    # Decision tree
    trees <- lapply(1:length(themes), function(i){
                        blaeu_tree(preprocessed_sets[[i]],
                                   clusters_sets[[i]],
                                   max_levels)
                        })
    cat("TIMING: decision_tree:", proc.time()["elapsed"] - TIME, "\n") ;

    trees 
}
