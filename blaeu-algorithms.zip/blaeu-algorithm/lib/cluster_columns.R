library(dynamicTreeCut)

#########
# Utils #
#########
plot_dendrogram <- function(dendro, file_name){
    if (is.null(dendro)) return()
    h <- attr(dendro, "members") / 4 
    pdf(file_name, height=h, width=5)
    par(mai=c(0.80, 0, 0, 3))
    plot(dendro, xlab="Variation Information", horiz=TRUE)
    dev.off()
}

#################
# Preprocessing #
#################
discretize <- function(data, nbins = 128){
    binned <- lapply(data, function(layer){
        as.numeric(cut(as.numeric(layer), nbins)) 
    })
    binned <- data.frame(binned)
    names(binned) <- names(data)
    
    binned
}

###############
# Clustering  #
###############
cluster_columns <- function(columns, print_results=FALSE) {
    # Trivial case
    if (ncol(columns) < 2) 
        return(list(
            clusters    = list(c(names(columns)[[1]])),
            dist_matrix = matrix(NA, nrow=1, ncol=1)
    ))
    
    # Calculates the distance pairs
    dist_matrix <- variation_information_m(columns)
    # Performs the clustering
    dist_object <- as.dist(dist_matrix)
    dendrogram <- hclust(dist_object, "complete")
    
    # Splits the dendrogram
    splits <- cutreeDynamic(dendrogram, minClusterSize=2, method="tree", 
                            deepSplit = FALSE)

    outliers <- (splits == 0)
    if (any(outliers))
        splits[outliers] <- seq(max(splits) +1, length = sum(outliers))
    clusters <- lapply(unique(splits), function(s) names(columns)[splits == s])
    print(clusters)
    
    # If necessary, plots
    if (print_results) 
        plot_dendrogram(as.dendrogram(dendrogram), "Atlas_dendrogram.pdf")
    # Returns
    list(clusters    = clusters,
         dist_matrix = dist_matrix)
}


###########
# Sorting #
###########
score_influence <- function(cols, dist_matrix){
    weights <- dist_matrix[!rownames(dist_matrix) %in% cols,cols]
    sum(weights)/length(cols)
}

rank_themes <- function(clusters, dist_matrix, print_results=FALSE){
    # Trivial case
    if (length(clusters) < 2) return(clusters)
    # Preprocesses the input distance matrix
    dist_matrix[is.na(dist_matrix)] <- 0
    dist_matrix <- dist_matrix + t(dist_matrix)
    # Gets the influence score for each map
    s  <- sapply(clusters, function(m) score_influence(m, dist_matrix))
    # Sorts
    order <- sort(s, decreasing=FALSE, index.return=TRUE)$ix
    s     <- s[order]
    clusters  <- clusters[order]
    
    # If needed, print results
    if (print_results)
        for (i in 1:length(clusters))
            cat("..... ", clusters[[i]], ",", s[i],"\n")
    
    # Returns everything
    clusters
}

############################
# Wrapping the whole thing #
############################
get_themes <- function(data, print_results=F){
    cat (" * Clustering columns\n")
    TIME <-  proc.time()["elapsed"]
    # Preprocessing
    data <- discretize(data)
    # Clustering
    analysis <- cluster_columns(data, print_results)
    # Ranking
    themes <- analysis$clusters
    # Done
    cat("TIMING: vertical", proc.time()["elapsed"] - TIME, "\n")
    return(themes)
}
