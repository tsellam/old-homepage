#!/usr/bin/env Rscript 
####################
# INFO THEORY IN R #
####################

#-------------------#
# ATOMIC OPERATIONS #
#-------------------#
sum_prod_log <- function(probs){
     sum(sapply(probs, function(x){x * log2(x)})) * -1
}

# Entropy of a series
entropy_R <- function(s1){
    freq <- table(s1)[]/length(s1)
    sum_prod_log(freq)
}

# Joint entropy
joint_entropy_R <- function(s1, s2){
    # Does the maths 
    freq <- c(table(s1,s2)/length(s1)) 
    freq <- freq[freq != 0]
    sums <- freq * log2(freq)
    sum(sums) * -1
}

### Mutual information
mutual_information <- function(s1, s2){
    entropy(s1) + entropy(s2) - joint_entropy(s1,s2)
}

# Variation of information
variation_information_R <- function(s1, s2){
    # Get entropy values
    ent1 <- entropy(s1)
    ent2 <- entropy(s2)
    joint_ent <- joint_entropy(s1, s2)
    # Result
    VI <- 2 * joint_entropy(s1,s2) - entropy(s1) - entropy(s2)
    max(0, VI)
}

#-----------------#
# BULK OPERATIONS #
#-----------------#
entropy_m <- function(m) {
    proba <- lapply(m, function(l){table(l)[]/length(l)})
    sapply(proba, sum_prod_log)
}

joint_entropy_i_l <- function(it, ma){
    sapply(ma, joint_entropy, it)
}

joint_entropy_m <- function(m){
    ncols <- length(m)
    out <- matrix(NA, nrow=ncols, ncol=ncols)
    for (j in 1:(ncols-1)) 
        out[(j+1):ncols, j] <- joint_entropy_i_l(m[[j]], m[(j+1):ncols])
    out
}

variation_information_m_R <- function(layers){
    # Calculations
    layers <- lapply(layers, factor)
    ncols <- length(layers)
    # repeats the entropy vector
    ent1  <- matrix(entropy_m(layers), nrow=ncols, ncol=ncols)
    ent2  <- t(ent1)
    joint_ent <- joint_entropy_m(layers) 
    VI <- apply(2 * joint_ent - ent1 - ent2, c(1,2),
        function(v) if (v>=0 || is.na(v)) v else 0)
    rownames(VI) <- names(layers)
    colnames(VI) <- names(layers)
    VI
}


####################
# INFO THEORY IN C #
####################
# File checks
lib <- paste0("info_theory.so")

# Leading functions
if (!file.exists(lib)){
    # R functions
    cat("Information Theory library not found!\n")
    entropy       <- entropy_R
    joint_entropy <- joint_entropy_R
    variation_information <- variation_information_R
    variation_information_m <- variation_information_m_R

} else {
    # C functions
    cat("Information Theory found!\n")
    # Loading the library
    dyn.load(lib)

    # Wrappers
    entropy <- function(series){
        if (length(series) < 2) return(0)
        series <- as.integer(factor(series))
        .Call("entropy", series)
    }

    joint_entropy <- function(s1, s2){
        s1 <- as.integer(factor(s1))
        s2 <- as.integer(factor(s2))
        .Call("jointEntropy", s1, s2)
    }

    variation_information <- function(s1, s2){
        s1 <- as.integer(factor(s1))
        s2 <- as.integer(factor(s2))
        .Call("variationInformation", s1, s2)
    }

    variation_information_m <- function(layers){
        layers <- lapply(layers, factor)
        mat <- do.call(cbind, layers)
        VI <- .Call("bulkVariationInformation", mat)
        rownames(VI) <- names(layers)
        colnames(VI) <- names(layers)
        VI
    }
}
