#!/bin/sh

# Compile the Information Theory functions 
(cd InfoTheory && R CMD SHLIB info_theory.c )

# Simple Map 
./SimpleMap.R iris.csv iris-subspaces.csv out_simple_map

# Decoupled Mapping 
./DM.R iris.csv out_dm

# Coarse Decoupled Mapping
./CoarseDM.R iris.csv out_cdm

# Check the results
ls out_* | xargs head
