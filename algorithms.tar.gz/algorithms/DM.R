#!/usr/bin/Rscript
options(scipen=999)
source("InfoTheory/info_theory.R", chdir=T)
###########################
##### Creating themes #####
############################

#########
# Utils #
#########
plot_dendrogram <- function(dendro, file_name){
    if (is.null(dendro)) return()
    h <- attr(dendro, "members") / 4 
    pdf(file_name, height=h, width=5)
    par(mai=c(0.80, 0, 0, 3))
    plot(dendro, xlab="Variation Information", horiz=TRUE)
    dev.off()
}

#################
# Preprocessing #
#################
discretize <- function(data, nbins = 16){
    binned <- lapply(data, function(layer){
        as.numeric(cut(layer, nbins)) 
    })
    binned <- data.frame(binned)
    names(binned) <- names(data)
    
    binned
}

###############
# Clustering  #
###############
cluster_columns <- function(columns, print_results=FALSE) {
    # Trivial case
    if (ncol(columns) < 2) 
        return(list(
            clusters    = list(c(names(columns)[[1]])),
            dist_matrix = matrix(NA, nrow=1, ncol=1)
    ))
    
    # Calculates the distance pairs
    dist_matrix <- variation_information_m(columns)
    # Performs the clustering
    dist_object <- as.dist(dist_matrix)
    clust_seq <- hclust(dist_object, "complete")$merge

    # Splits the big clusters
    clusters <- cut_chains(clust_seq, 1:ncol(columns))
    clusters <- lapply(clusters, function(c) names(columns)[c])
    
    # If necessary, plots
    if (print_results) 
        plot_dendrogram(dendrogram, "Atlas_dendrogram.pdf")
    # Returns
    list(clusters    = clusters,
         dist_matrix = dist_matrix)
}

##########################
# Cutting the dendrogram #
##########################
tag <- function(clust){
    keep <- rep(FALSE, nrow(clust))
    
    sapply(1:nrow(clust), function(i){
        
        if (all(clust[i,] > 0)){
            return()
        }
        if(all(clust[i,] < 0)){
            keep[i] <<- TRUE
            return()
        }
        
        indices <- clust[i,]
        
        j <- indices[indices > 0]
        if(all(keep[j])){
            keep[i] <<- TRUE
            keep[j] <<- FALSE
        }
        return()
    })
    
    return(keep)
}

fetch_nodes <- function(i, clust){    
    indices <- clust[i,]
    
    out <- -1 * indices[indices < 0]
    
    js <- indices[indices > 0]
    if (length(js) > 0){
        kids <- lapply(js, fetch_nodes, clust)
        out <- c(out, unlist(kids))
    }
    
    return(out)
}

build <- function(clust, tags, indices){
    clus_indices <- which(tags)
    clusters     <- lapply(clus_indices, fetch_nodes, clust)
    
    clustered   <- unique(unlist(clusters))
    unclustered <- indices[!indices %in% clustered]
    out <- append(clusters, lapply(unclustered, I))

    return(out)
}

cut_chains <- function(clust_seq, objects){
    tags <- tag(clust_seq)
    out <- build(clust_seq, tags, objects)
    return(out)
}

###########
# Sorting #
###########
score_influence <- function(cols, dist_matrix){
    weights <- dist_matrix[!rownames(dist_matrix) %in% cols,cols]
    sum(weights)/length(cols)
}

rank_themes <- function(clusters, dist_matrix, print_results=FALSE){
    # Trivial case
    if (length(clusters) < 2) return(clusters)
    # Preprocesses the input distance matrix
    dist_matrix[is.na(dist_matrix)] <- 0
    dist_matrix <- dist_matrix + t(dist_matrix)
    # Gets the influence score for each map
    s  <- sapply(clusters, function(m) score_influence(m, dist_matrix))
    # Sorts
    order <- sort(s, decreasing=FALSE, index.return=TRUE)$ix
    s     <- s[order]
    clusters  <- clusters[order]
    
    # If needed, print results
    if (print_results)
        for (i in 1:length(clusters))
            cat("..... ", clusters[[i]], ",", s[i],"\n")
    
    # Returns everything
    clusters
}

############################
# Wrapping the whole thing #
############################
get_themes <- function(data, print_results=F){
    # Preprocessing
    data <- discretize(data)
    # Clustering
    analysis <- cluster_columns(data, print_results)
    # Ranking
    themes <- rank_themes(analysis$clusters, analysis$dist_matrix, print_results)
    # Done
    return(themes)
}

###########################
##### Simple Mapping #####
############################

############
# Plotting #
############
colors <- c(
    "#E41A1C",
    "#377EB8",
    "#4DAF4A",
    "#984EA3",
    "#FF7F00",
    "#FFFF33",
    "#A65628",
    "#F781BF"
)

# Plots a map
plot_maps <- function(data, themes, maps, file_name){
    pdf(file_name)
    for (i in 1:length(themes)){
        # Unpacks results
        cols <- themes[[i]]
        map  <- as.numeric(factor(maps[[i]]$model))
        # Plots the data
        map_name <- paste(cols, collapse = ", ")
        point <- if (nrow(data) > 1000){
            "." 
        } else if (nrow(data) > 500){
            "+"
        } else {
            18
        }
        if (length(cols) > 1) {
            pairs(data[,cols], col=colors[map], main=map_name, pch=point)
        } else {
            hist(data[,cols],  main=map_name)
        }
    }
    dev.off()
}

#########################
# Managing descriptions #
#########################
create_nodes <- function(col_name, data, model){
    # Creates the nodes
    nodes <- lapply(unique(model), function(c){
        selection <- data[model==c]
        r <- range(selection)
        n <- length(selection)
        list(id    = c,
             col   = col_name,
             min   = r[1],
             max   = r[2],
             count = n,
             children = NULL
        )
    })
    
    # Sorts them
    ord <- order(sapply(nodes, function(n) n$min))
    nodes[ord]
}

insert_nodes <- function(tree, id, new_nodes){
    # .. If we are at the right leaf
    if (tree$id == id){
        # Updates the IDs and inserts
        tree$children <- lapply(new_nodes, function(node) {
            node$id <- 10*id + node$id
            return(node)
        })
        return(tree)
    }
    
    # .. Wrong leaf, no children
    if (is.null(tree$children)) return(tree)
    
    # .. Wrong leaf, children
    tree$children <- lapply(tree$children, insert_nodes, id, new_nodes)
    return(tree)
}

printTree <- function(tree, level = 0){
    cat(paste(rep(".", level * 2), collapse=""))
    cat("Node ", tree$id, "column", tree$col, 
        "between", tree$min, "and", tree$max, 
        ", count:", tree$count, "\n")
    lapply(tree$children, printTree, level + 1)
}

###########
# Metrics #
###########
# Gets the squared intr-cluster distance
quality_cluster <- function(data) {
    if (is.null(data) || any(is.nan(data))) {
        0
    } else {
        sum((data - mean(data, na.rm = TRUE))^2)
    }
}

quality_clustering <- function(data, map){
    clust_wss <- sapply(unique(map), function(c){
        quality_cluster(data[which(map==c)])
    })
    sum(clust_wss)
}

#######################
# Splitting primitive #
#######################
kmeans_split <- function(vect){
    out <- kmeans(vect, 2, nstart=5)
    list(
        clustering = out$cluster,
        quality    = out$tot.withinss
    )
}

atom_split <- function(vect){
  clustering <- as.integer(factor(vect))
  quality    <- quality_clustering(vect, clustering)
  list(
      clustering = clustering,
      quality    = quality
  )
}

split <- function(vect){
    n_distinct <- length(unique(vect))
    if (n_distinct  < 2)  return(list(clustering=NULL, quality=Inf))
    if (n_distinct == 2)  return(atom_split(vect))
    return(kmeans_split(vect))
}

####################
# Divisive k-means #
####################
partition_cluster <- function(selection){
    # Scales
    scaled <- scale(selection)
    # Split each column - each split is a triplet clustering/quality/description
    splits <- apply(scaled, 2, split)
    # Gets the best cut
    scores     <- sapply(splits, function(split) split$quality)
    best_split <- which.min(scores)
    new_model  <- splits[[best_split]]$clustering
    # Gets descriptions
    best_name <- colnames(scaled)[best_split]
    nodes     <- create_nodes(best_name, selection[,best_name], new_model)
    # Returns the package!
    return(list(
        model = new_model,
        nodes = nodes
    ))
}

partition <- function(data, max_k = 8){
    # Trivial cases
    if (is.null(data) || ncol(data) < 1 || nrow(data) < 1)
        return(NULL)

    # Cleaning and conversions
    data_matrix       <- as.matrix(data)
    clean_data_matrix <- na.omit(data_matrix)
    NAs <- attr(clean_data_matrix,"na.action")
    
    # Creates one big cluster
    model     <- rep(0, nrow(clean_data_matrix))
    for (level in 1:(max_k-1)){
        
        # Gets the size of each cluster, gets biggest
        tab <- table(model)
        clus <- as.numeric(names(which.max(tab)))
        
        # Extracts the values
        selection <- which(model==clus)
        to_split  <- clean_data_matrix[selection,,drop=FALSE]
        
        # Splits and udpates
        out       <- partition_cluster(to_split)
        new_model <- out$model
        new_nodes <- out$nodes
        if (!is.null(new_model)){
            model[selection] <- clus*10 + new_model
        }
    }
    
    # Fills NAs
    if (!is.null(NAs)){
        f_model <- rep(NA, nrow(data_matrix))
        f_model[-NAs] <- model
    } else {
        f_model <- model
    }
    
    # Done!
    return(f_model)
}

###############
# Wrapping up #
###############
create_maps <- function(data, themes, max_k=5, print_results=FALSE){
    # Does the partitionnig
    map_set <- lapply(themes, function(cols, data, max_k) {
        partition(data[cols], max_k)
    }, data, max_k)
    
    # Plots and returns
    if (print_results) plot_maps(data, themes, map_set, "Atlas_items.pdf")
    map_set
}

############
# COMMANDS #
############
arguments <- commandArgs(trailingOnly = TRUE)
data_file   <- arguments[1]
out         <- arguments[2]
k <- if (is.na(arguments[3])) 5 else as.numeric(arguments[3])
TIME <- proc.time()["elapsed"]

cat("Running Decoupled Mapping on file", data_file, "\n")

# Reads the data file
data <- read.csv(data_file, header=FALSE, sep=";")
names(data) <- paste("map", 1:ncol(data), sep="")

# Removes useless columns
clean_names <- names(data)
for (col in names(data)){
    if (length(unique(data[[col]])) <= k){
        data[[col]] <- NULL
    }
}
if (length(clean_names) > length(names(data)))
    warning("Dropped ", length(clean_names) - length(names(data)), " columns", immediate. = TRUE)
cat("TIMING: readfile", proc.time()["elapsed"] - TIME, "\n") ; TIME <- proc.time()["elapsed"]

# Reads the clusters file
themes <- get_themes(data)
cat("TIMING: vertical", proc.time()["elapsed"] - TIME, "\n") ; TIME <- proc.time()["elapsed"]

# Clusters
map <- create_maps(data, themes, max_k=k)
cat("TIMING: clusters", proc.time()["elapsed"] - TIME, "\n") ; TIME <- proc.time()["elapsed"]

# Writes output
cat("Output of DM clustering\n", file=out)
for (i in 1:length(themes)){
    theme_bin <- rep(0, length(clean_names))
    theme_bin[which(clean_names %in% themes[[i]])] <- 1
    for (cluster in unique(map[[i]])){
        items <- which(map[[i]] == cluster) - 1
        cat(theme_bin, 
            length(items),
            items,
            "\n",
            file=out, append=TRUE)
    }
}

cat("TIMING: writefile", proc.time()["elapsed"] - TIME, "\n") ; TIME <- proc.time()["elapsed"]
